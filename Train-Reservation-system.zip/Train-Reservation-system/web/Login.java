
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author nawad
 */
public class Login extends HttpServlet {


 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     
        response.setContentType("text/html");  
        PrintWriter out = response.getWriter();  

        String n=request.getParameter("username");  
        String p1=request.getParameter("password_1");  
       


        try{  
        //Class.forName("oracle.jdbc.driver.OracleDriver");  
        Connection con=DriverManager.getConnection(  
        "jdbc:derby://localhost:1527/sample1","app","app");  

        PreparedStatement ps=con.prepareStatement(  
        "select * from users  where username=? ");  
         ps.setString(1,n);  
        ResultSet  rs=ps.executeQuery();  
         
        if(!rs.next())  {
        out.print("User Does not exist");  
        }
        else{
        PreparedStatement ps2=con.prepareStatement(  
        "select * from users  where username=? and password=? ");  
            ps2.setString(1,n); 
         ps2.setString(2,p1);  
        ResultSet  rs2=ps.executeQuery();
        if(!rs2.next())  {
        out.print("Incorrect Password");  
        }
        else{
            RequestDispatcher rd=request.getRequestDispatcher("userHome.html");  
            rd.forward(request, response);
        }
            
        }

        }catch (Exception e2) {System.out.println(e2);}  

        out.close();  
}  
  
}  