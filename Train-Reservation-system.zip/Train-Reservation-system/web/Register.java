import java.io.*;  
import java.sql.*;  
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;  
import javax.servlet.http.*;  
  
public class Register extends HttpServlet {  
public void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
  
response.setContentType("text/html");  
PrintWriter out = response.getWriter();  
          
String n=request.getParameter("username");  
String p1=request.getParameter("password_1");  
String p2=request.getParameter("password_2"); 
String e=request.getParameter("email");  
  
          
try{  
//Class.forName("oracle.jdbc.driver.OracleDriver");  
Connection con=DriverManager.getConnection(  
"jdbc:derby://localhost:1527/sample1","app","app");  
  PreparedStatement ps1=con.prepareStatement(  
        "select * from users  where username=? ");  
         ps1.setString(1,n);  
        ResultSet  rs=ps1.executeQuery();  
if(!rs.next()){
PreparedStatement ps=con.prepareStatement(  
"insert into users values(?,?,?)");  
if(p1.equals(p2)){
    ps.setString(1,n);  
    ps.setString(2,p2);  
    ps.setString(3,e);  
        int i=ps.executeUpdate(); 
        if(i>0){
            out.println("<script>alert('Successfull')</script>");
            out.print("You are successfully registered...");  
            RequestDispatcher rd=request.getRequestDispatcher("login.html");  
            rd.forward(request, response);
        }
        else{
            out.print("Error");
        }
    }
    else{
        out.print("Passwords don't match");
    }

          

}
else{
    out.print("UserName Exists");
}
}catch (Exception e2) {System.out.println(e2);}  
          
out.close();  
}  
  
}  